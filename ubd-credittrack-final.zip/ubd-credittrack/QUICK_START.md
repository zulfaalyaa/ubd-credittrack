# 🚀 QUICK START GUIDE - UBD CreditTrack

## ⏱️ Get Running in 10 Minutes!

### Option 1: Deploy Online (Recommended for Presentation)

#### Step 1: Supabase (3 minutes)
1. Go to https://supabase.com → Sign up
2. Create new project: `ubd-credittrack`
3. Go to Settings → API → Copy:
   - Project URL
   - anon/public key
4. Go to SQL Editor → Paste `database-schema.sql` → Run

#### Step 2: GitHub (2 minutes)
1. Go to https://github.com → Create new repository
2. Name: `ubd-credittrack`
3. Upload all files from this folder

#### Step 3: Render (5 minutes)
1. Go to https://render.com → Sign up with GitHub
2. New → Web Service → Connect `ubd-credittrack` repo
3. Settings:
   - Build: `npm install`
   - Start: `npm start`
   - Add environment variables:
     * SUPABASE_URL = (your URL)
     * SUPABASE_ANON_KEY = (your key)
     * PORT = 3000
4. Create Web Service → Wait 3 minutes

✅ **DONE! Your app is live!**

---

### Option 2: Run Locally (For Testing)

```bash
# 1. Install dependencies
npm install

# 2. Create .env file
cp .env.example .env

# 3. Edit .env with your Supabase credentials
# SUPABASE_URL=your_url_here
# SUPABASE_ANON_KEY=your_key_here

# 4. Start server
npm start

# 5. Open browser
# http://localhost:3000
```

---

## 🎯 How to Use

### Login
- Enter registration number: `22B6000`
- Click Sign In

### Add Modules
1. Select your programme
2. Click "Add Module"
3. Type module code: `ZS-4301`
4. Name auto-fills to "Cloud Computing"
5. Click "Save Module"

### Track Progress
- Dashboard shows overall progress
- Breakdown page shows category details
- Modules page shows all added modules

---

## 📱 Test Credentials

Use these registration numbers for testing:
- `22B6000`
- `21B4521`
- `23A1234`

---

## 🆘 Troubleshooting

### "Cannot connect to database"
→ Check SUPABASE_URL and SUPABASE_ANON_KEY in Render environment variables

### "Module not found"
→ Make sure you selected a programme first

### "Service Unavailable"
→ Render free tier sleeps after 15 mins - first request takes 30-60 seconds

---

## 📚 Full Documentation

- `README.md` - Complete user guide
- `DEPLOYMENT.md` - Detailed deployment steps
- `TECHNICAL_REPORT.md` - Full technical documentation

---

## ✨ Features Checklist

- ✅ Login with registration number
- ✅ 5 SDS programmes supported
- ✅ 300+ modules pre-loaded
- ✅ Auto-complete module search
- ✅ Auto-fill module details
- ✅ Real-time credit tracking
- ✅ Category breakdown
- ✅ Remove modules
- ✅ Beautiful responsive UI
- ✅ Mobile-friendly
- ✅ Cloud deployed

---

## 🎓 Presentation Tips

1. **Show Login**: Enter `22B6000`
2. **Select Programme**: Choose "Cybersecurity and Forensics"
3. **Add Module**: Type `ZS-4301` - watch auto-fill
4. **Show Dashboard**: Point out real-time progress (4/152 MC)
5. **Show Breakdown**: Explain category tracking
6. **Add More Modules**: Add `ZS-2201`, `ZC-2205`, etc.
7. **Show Progress Update**: Dashboard updates automatically
8. **Demo Remove**: Click remove button
9. **Show Mobile**: Resize browser or use phone

---

## 🌐 Your URLs

After deployment:
- **App**: https://your-app.onrender.com
- **GitHub**: https://github.com/your-username/ubd-credittrack
- **Supabase**: https://supabase.com/dashboard

---

**Good luck with your presentation! 🎉**

Made by: Zulfa 'Alyaa (22B6000)
Course: ZS-4301 Cloud Computing
UBD School of Digital Science

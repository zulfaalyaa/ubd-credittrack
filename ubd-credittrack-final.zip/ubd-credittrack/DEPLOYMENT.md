# Deployment Guide - UBD CreditTrack

## Step-by-Step Deployment to Render + Supabase

### Part 1: Supabase Database Setup (5 minutes)

1. **Create Supabase Account**
   - Go to https://supabase.com
   - Click "Start your project"
   - Sign up with GitHub/Google/Email

2. **Create New Project**
   - Click "New Project"
   - Choose organization (or create new one)
   - Project name: `ubd-credittrack`
   - Database password: Generate a strong password (SAVE THIS!)
   - Region: Choose closest to Brunei (Singapore recommended)
   - Click "Create new project"
   - Wait 2-3 minutes for setup

3. **Get API Credentials**
   - Go to Project Settings (gear icon) > API
   - Copy these TWO values (you'll need them later):
     * **Project URL**: `https://xxxxx.supabase.co`
     * **anon/public key**: `eyJhbGciOi...` (long string)

4. **Create Database Tables**
   - Click "SQL Editor" in left sidebar
   - Click "New Query"
   - Copy and paste the ENTIRE contents of `database-schema.sql`
   - Click "Run" or press Ctrl+Enter
   - You should see "Success. No rows returned"

5. **Verify Tables Created**
   - Click "Table Editor" in left sidebar
   - You should see two tables: `users` and `modules`

✅ **Supabase setup complete!**

---

### Part 2: GitHub Repository Setup (3 minutes)

1. **Create GitHub Account** (if you don't have one)
   - Go to https://github.com
   - Sign up for free

2. **Create New Repository**
   - Click the "+" icon > "New repository"
   - Repository name: `ubd-credittrack`
   - Make it Public
   - Do NOT add README, .gitignore, or license
   - Click "Create repository"

3. **Upload Your Code**
   
   **Option A: Using Git (recommended)**
   ```bash
   cd ubd-credittrack
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/ubd-credittrack.git
   git push -u origin main
   ```

   **Option B: Using GitHub Website**
   - On your repository page, click "uploading an existing file"
   - Drag and drop ALL files from your project folder
   - Write commit message: "Initial commit"
   - Click "Commit changes"

✅ **Code is now on GitHub!**

---

### Part 3: Render Deployment (5 minutes)

1. **Create Render Account**
   - Go to https://render.com
   - Click "Get Started"
   - Sign up with GitHub (easiest option)
   - Authorize Render to access your repositories

2. **Create New Web Service**
   - Click "New +" button > "Web Service"
   - Click "Connect account" if needed
   - Find and select `ubd-credittrack` repository
   - Click "Connect"

3. **Configure Service**
   Fill in these settings:
   
   **Basic Settings:**
   - Name: `ubd-credittrack` (or your choice)
   - Region: Singapore (closest to Brunei)
   - Branch: `main`
   - Root Directory: (leave blank)
   - Environment: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`

   **Instance Type:**
   - Select "Free" (0 USD/month)

4. **Add Environment Variables**
   - Scroll down to "Environment Variables"
   - Click "Add Environment Variable"
   
   Add these THREE variables one by one:
   
   | Key | Value |
   |-----|-------|
   | `SUPABASE_URL` | Your Supabase Project URL from Part 1 |
   | `SUPABASE_ANON_KEY` | Your Supabase anon key from Part 1 |
   | `PORT` | `3000` |

5. **Deploy!**
   - Click "Create Web Service"
   - Wait 3-5 minutes for deployment
   - Watch the logs to see progress

6. **Access Your App**
   - Once deployed, you'll see "Your service is live 🎉"
   - Your URL: `https://ubd-credittrack.onrender.com` (or similar)
   - Click the URL to open your app!

✅ **Deployment complete!**

---

### Part 4: Testing Your Deployed App

1. **Test Login**
   - Go to your Render URL
   - Enter registration number: `22B6000`
   - Click "Sign In"
   - Should see dashboard

2. **Test Module Adding**
   - Select programme: "Cybersecurity and Forensics"
   - Click "Modules" tab
   - Click "Add Module"
   - Type `ZS-4301`
   - Should auto-fill with "Cloud Computing"
   - Click "Save Module"
   - Module should appear in table

3. **Test Dashboard**
   - Click "Dashboard" tab
   - Should see progress updated
   - Should show 4/152 MC

4. **Test Breakdown**
   - Click "Breakdown" tab
   - Should see category breakdown
   - Should show alerts for incomplete requirements

✅ **All features working!**

---

## Your App URLs

After deployment, you'll have:

1. **Production URL**: `https://YOUR-APP-NAME.onrender.com`
2. **Supabase Dashboard**: `https://supabase.com/dashboard/project/YOUR_PROJECT_ID`
3. **GitHub Repo**: `https://github.com/YOUR_USERNAME/ubd-credittrack`
4. **Render Dashboard**: `https://dashboard.render.com`

---

## Common Issues & Solutions

### Issue: Build Failed on Render

**Solution:**
- Check that `package.json` exists in repository
- Verify Build Command is `npm install`
- Check logs for specific error
- Ensure Node version is compatible (18+)

### Issue: App Crashes After Deployment

**Solution:**
- Check environment variables are set correctly
- View logs in Render dashboard
- Verify Start Command is `npm start`
- Check Supabase credentials are correct

### Issue: Database Connection Error

**Solution:**
- Verify SUPABASE_URL in environment variables
- Verify SUPABASE_ANON_KEY in environment variables
- Check that database schema was run in Supabase
- Ensure RLS policies are enabled

### Issue: Modules Not Loading

**Solution:**
- Check that `modules-data.js` is in `public/` folder
- Clear browser cache
- Check browser console for JavaScript errors
- Verify file is included in index.html

### Issue: "Service Unavailable" Error

**Solution:**
- Render free tier sleeps after 15 mins of inactivity
- First request may take 30-60 seconds to wake up
- This is normal for free tier
- Upgrade to paid tier for always-on service

---

## Updating Your App

When you make changes:

1. **Update your code locally**
2. **Push to GitHub:**
   ```bash
   git add .
   git commit -m "Your change description"
   git push
   ```
3. **Render auto-deploys!**
   - Render detects GitHub push
   - Automatically rebuilds and deploys
   - Wait 2-3 minutes

---

## Monitoring

### Check Logs (Render)
1. Go to Render dashboard
2. Click your service
3. Click "Logs" tab
4. See real-time server logs

### Check Database (Supabase)
1. Go to Supabase dashboard
2. Click "Table Editor"
3. View `users` and `modules` tables
4. See all data in real-time

---

## Performance Notes

### Free Tier Limitations

**Render Free:**
- App sleeps after 15 minutes of inactivity
- First request after sleep takes 30-60 seconds
- 750 hours/month (enough for most use)
- Good for development and testing

**Supabase Free:**
- 500MB database
- Unlimited API requests
- Good for small to medium projects

### Upgrading

If you need better performance:
- **Render**: $7/month for always-on
- **Supabase**: $25/month for Pro (8GB database)

---

## Security Best Practices

1. **Never commit `.env` file**
   - Already in `.gitignore`
   - Use environment variables in Render

2. **Rotate keys regularly**
   - Change Supabase keys every 3-6 months
   - Update in Render environment variables

3. **Monitor database**
   - Check Supabase logs regularly
   - Set up alerts for unusual activity

---

## Backup & Recovery

### Database Backup
1. Go to Supabase dashboard
2. Database > Backups
3. Download backup (automatic daily backups on paid tier)

### Code Backup
- Your code is safe on GitHub
- Can redeploy anytime from repository

---

## Getting Help

If you're stuck:

1. **Check logs first**
   - Render: Service > Logs
   - Browser: F12 > Console
   - Supabase: Logs & Reports

2. **Common resources**
   - Render Docs: https://render.com/docs
   - Supabase Docs: https://supabase.com/docs
   - Stack Overflow: Search your error message

3. **Test locally**
   - Run `npm start` on your computer
   - Check if it works locally first
   - Then deploy

---

## Success Checklist

- [ ] Supabase project created
- [ ] Database schema executed
- [ ] API credentials copied
- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Render service created
- [ ] Environment variables added
- [ ] App deployed successfully
- [ ] Can login with registration number
- [ ] Can add modules
- [ ] Dashboard shows progress
- [ ] URL shared with lecturer/classmates

🎉 **Congratulations! Your app is live!**
